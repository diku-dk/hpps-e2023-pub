#include "io.h"
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>

double* read_points(FILE *f, int* n_out, int *d_out) {
  assert(0);
}

int* read_indexes(FILE *f, int *n_out, int *k_out) {
  assert(0);
}

int write_points(FILE *f, int32_t n, int32_t d, double *data) {
  assert(0);
}

int write_indexes(FILE *f, int32_t n, int32_t k, int *data) {
  assert(0);
}

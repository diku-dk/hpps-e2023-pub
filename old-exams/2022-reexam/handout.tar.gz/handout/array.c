#include "array.h"
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

struct array* read_array(const char* file) {
  FILE *f = fopen(file, "rb");
  struct array* ret = NULL;

  if (f == NULL) {
    return NULL;
  }

  int32_t n;
  if (fread(&n, sizeof(int32_t), 1, f) != 1) {
    goto end;
  }

  if (n < 0) {
    goto end;
  }

  ret = malloc(sizeof(struct array));
  ret->n = n;
  ret->elements = calloc(n, sizeof(double));

  if (fread(ret->elements, sizeof(double), n, f) != (size_t)n) {
    free(ret->elements);
    free(ret);
    ret = NULL;
  }

  end:
  fclose(f);
  return ret;
}

int write_array(const char* file, struct array* arr) {
  FILE* f = fopen(file, "wb");
  int ret = 0;

  if (f == NULL) {
    return 1;
  }

  if (fwrite(&arr->n, sizeof(int), 1, f) != 1) {
    ret = 1;
  }
  if (fwrite(arr->elements, sizeof(double), arr->n, f) != (size_t)arr->n) {
    ret = 1;
  }
  fclose(f);
  return ret;
}

void free_array(struct array* arr) {
  free(arr->elements);
  free(arr);
}

int array_n(struct array* arr) {
  return arr->n;
}

double array_idx(struct array* arr, int i) {
  return arr->elements[i];
}

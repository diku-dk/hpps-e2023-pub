#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "histogram.h"
#include "timing.h"


int main(int argc, char** argv) {
  if (argc != 5) {
    fprintf(stderr, "Usage: %s ARRAY-FILE BINS BLOCKS RUNS\n", argv[0]);
    exit(1);
  }

  struct array* arr = read_array(argv[1]);
  if (arr == NULL) {
    fprintf(stderr, "Cannot read array from %s: %s\n", argv[1], strerror(errno));
    exit(1);
  }

  int bins = atoi(argv[2]);
  int blocks = atoi(argv[3]);
  int runs = atoi(argv[4]);
  
  uint64_t bef = microseconds();
  for (int r = 0; r < runs; r++) {
    struct histogram* hist = histogram_blocked(arr, bins, blocks);
    free_histogram(hist);
  }
  uint64_t aft = microseconds();
  printf("%f\n", (double)(aft-bef)/runs/1000000);
  free_array(arr);
}
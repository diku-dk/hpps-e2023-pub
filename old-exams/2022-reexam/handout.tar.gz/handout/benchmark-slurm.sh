#!/usr/bin/env bash

ELEMENTS=(10000 1000000 10000000)
BINS=(128 2048 32768 524288 8388608 134217728)
THREADS=(1 2 3 4 5 6 7 8 16 32)
BLOCKS=(1 2 4 8 16 32 64 128)
PERPASSES=(1 16 256 4096 65536)
REPEATS=100

echo "experiment,threads,elements,bins,blocks,per pass,mean time" > benchmark.csv

for ELEMENT in ${ELEMENTS[@]}; do
    for BIN in ${BINS[@]}; do
        sbatch --exclusive slurm_setup_simple.sh $PWD $ELEMENT $BIN $REPEATS
    done
done

for ELEMENT in ${ELEMENTS[@]}; do
    for BIN in ${BINS[@]}; do
        for THREAD in ${THREADS[@]}; do
            sbatch --exclusive slurm_setup_parallel.sh $PWD $THREAD $ELEMENT $BIN $REPEATS
        done
    done
done

for ELEMENT in ${ELEMENTS[@]}; do
    for BIN in ${BINS[@]}; do
        for BLOCK in ${BLOCKS[@]}; do
            for THREAD in ${THREADS[@]}; do
                sbatch --exclusive slurm_setup_blocked.sh $PWD $THREAD $ELEMENT $BIN $BLOCK $REPEATS
            done
        done
    done
done

for ELEMENT in ${ELEMENTS[@]}; do
    for BIN in ${BINS[@]}; do
        for PERPASS in ${PERPASSES[@]}; do
            for THREAD in ${THREADS[@]}; do
                sbatch --exclusive slurm_setup_multi_pass.sh $PWD $THREAD $ELEMENT $BIN $PERPASS $REPEATS
            done
        done
    done
done

for ELEMENT in ${ELEMENTS[@]}; do
    for BIN in ${BINS[@]}; do
        for BLOCK in ${BLOCKS[@]}; do
            for PERPASS in ${PERPASSES[@]}; do
                for THREAD in ${THREADS[@]}; do
                    sbatch --exclusive slurm_setup_blocked_multi_pass.sh $PWD $THREAD $ELEMENT $BIN $BLOCK $PERPASS $REPEATS
                done
            done
        done
    done
done

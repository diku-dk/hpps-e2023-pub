#include "histogram.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void free_histogram(struct histogram* hist) {
  free(hist->bins);
  free(hist);
}

// NOTE - This function should be left unaltered as a baseline to measure 
// speedups against
struct histogram* histogram_simple(struct array* arr, int bins) {
  struct histogram* hist = malloc(sizeof(struct histogram));
  hist->n = bins;
  hist->bins = calloc(hist->n, sizeof(int));

  // A crude histogram calculation, inspecting each element one by one
  for (int i=0; i<arr->n; i++) {
    int bin = (int)arr->elements[i];
    hist->bins[bin]++;
  }

  return hist;
}

// NOTE - This function should be modified to work in parallel. It is up to you
// to determine if this code is suitable for parallelisation as is, or if it 
// requires modifications (small or large)
struct histogram* histogram_parallel(struct array* arr, int bins) {
  struct histogram* hist = malloc(sizeof(struct histogram));
  hist->n = bins;
  hist->bins = calloc(hist->n, sizeof(int));

  // A crude histogram calculation, inspecting each element one by one
  for (int i=0; i<arr->n; i++) {
    int bin = (int)arr->elements[i];
    hist->bins[bin]++;
  }

  return hist;
}

// NOTE - This function provides a sequential basis for dividing the input 
// array into blocks. It should be modified to work in parallel. It is up to 
// you to determine if this code is suitable for parallelisation as is, or if 
// it requires modifications (small or large)
struct histogram* histogram_blocked(struct array* arr, int bins, int blocks) {
  struct histogram* hist = malloc(sizeof(struct histogram));
  hist->n = bins;
  hist->bins = calloc(hist->n, sizeof(int));

  int block_len = arr->n / blocks;

  // Divide the original array into blocks
  for (int b=0; b<blocks; b++) {
    // Inspect each element in the block one by one
    for (int i=0; i<block_len; i++) {
      int bin = (int)arr->elements[(b*block_len)+i];
      hist->bins[bin]++;
    }
  }

  return hist;
}

// NOTE - This function provides a sequential basis for only counting certain 
// bins per pass through the input array. It should be modified to work in 
// parallel. It is up to you to determine if this code is suitable for 
// parallelisation as is, or if it requires modifications (small or large)
struct histogram* histogram_multipass(struct array* arr, int bins, int per_pass) {
  struct histogram* hist = malloc(sizeof(struct histogram));
  hist->n = bins;
  hist->bins = calloc(hist->n, sizeof(int));

  int passes = (int)ceil((double)bins / per_pass);

  // Divide the histogram bins into passes
  for (int p=0; p<passes; p++) {
    // Inspect each element in the array one by one
    for (int i=0; i<arr->n; i++) {
      // If the element is in range for this pass, update the histogram
      if (arr->elements[i] >= p*per_pass && arr->elements[i] < (p*per_pass)+per_pass) {
        int bin = (int)arr->elements[i];
        hist->bins[bin]++;
      }
    }
  }
  return hist;
}

// NOTE - This function provides a sequential basis for only counting certain 
// bins per pass through an input array divided into blocks.  It should be 
// modified to work in parallel.It is up to you to determine if this code is 
// suitable for parallelisation as is, or if it requires modifications (small 
// or large)
struct histogram* histogram_blocked_multipass(struct array* arr, int bins, int blocks, int per_pass) {
  struct histogram* hist = malloc(sizeof(struct histogram));
  hist->n = bins;
  hist->bins = calloc(hist->n, sizeof(int));

  int block_len = arr->n / blocks;
  int passes = (int)ceil((double)bins / per_pass);

  // Divide the histogram bins into passes
  for (int p=0; p<passes; p++) {
    // Divide the original array into blocks
    for (int b=0; b<blocks; b++) {
      // Inspect each element in the block one by one
      for (int i=0; i<block_len; i++) {
        int index = (b*block_len)+i;
        // If the element is in range for this pass, update the histogram
        if (arr->elements[index] >= p*per_pass && arr->elements[index] < (p*per_pass)+per_pass) {
          int bin = arr->elements[index];
          hist->bins[bin]++;
        }
      }
    }
  }

  return hist;
}

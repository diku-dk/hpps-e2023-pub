#ifndef HISTOGRAM_H
#define HISTOGRAM_H

#include "array.h"

struct histogram {
  int n;
  int *bins;
};

void free_histogram(struct histogram*);

struct histogram* histogram_simple(struct array* arr, int bins);
struct histogram* histogram_parallel(struct array* arr, int bins);
struct histogram* histogram_blocked(struct array* arr, int bins, int blocks);
struct histogram* histogram_multipass(struct array* arr, int bins, int pass);
struct histogram* histogram_blocked_multipass(struct array* arr, int bins, int blocks, int pass);

#endif

#!/usr/bin/env bash

export OMP_NUM_THREADS=${1}
echo "Benchmarking histogram-blocked on datafiles/${2}-${3}.arr with ${1} threads and ${4} blocks"
time ./benchmark-blocked-histogram datafiles/${2}-${3}.arr ${3} ${4} ${5]}

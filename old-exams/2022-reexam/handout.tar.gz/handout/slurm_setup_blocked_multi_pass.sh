#!/usr/bin/env bash

echo "Setting up environment at ${1}"
apptainer exec ~/modi_images/hpc-notebook-latest.sif ${1}/slurm_run_blocked_multi_pass.sh ${2} ${3} ${4} ${5} ${6} ${7}

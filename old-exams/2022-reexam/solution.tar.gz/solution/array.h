#ifndef ARRAY_H
#define ARRAY_H

struct array {
  int n;
  double *elements;
};

struct array* read_array(const char* file);
int write_array(const char* file, struct array*);
void free_array(struct array*);
int array_n(struct array*);
double array_idx(struct array*, int i);

#endif
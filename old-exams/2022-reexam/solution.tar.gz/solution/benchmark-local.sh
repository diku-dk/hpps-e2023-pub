#!/usr/bin/env bash

set -e

ELEMENTS=(10000 1000000 100000000 1000000000)
BINS=(128 2048 32768 524288 8388608 134217728)
THREADS=(1 2 4 8 16)
BLOCKS=(2 4 8 16 32 64)
PASSES=(2 4 8 16 32 64)
REPEATS=10

start_time=$(date +%s)

echo "experiment,threads,elements,bins,blocks,per pass,mean time" > benchmark.csv

for ELEMENT in ${ELEMENTS[@]}; do
    for BIN in ${BINS[@]}; do
        echo "Benchmarking histogram-simple on datafiles/$ELEMENT-$BIN.arr"
        echo -n "simple,,$ELEMENT,$BIN,,," >> benchmark.csv
        ./benchmark-simple-histogram datafiles/$ELEMENT-$BIN.arr $BIN $REPEATS >> benchmark.csv
        if (($? == 137));
        then
            echo "Killed" >> benchmark.csv
        fi
    done
done

for ELEMENT in ${ELEMENTS[@]}; do
    for BIN in ${BINS[@]}; do
        for THREAD in ${THREADS[@]}; do
            echo "Benchmarking histogram-parallel on datafiles/$ELEMENT-$BIN.arr with $THREAD thread(s)"
            echo -n "parallel,$THREAD,$ELEMENT,$BIN,,," >> benchmark.csv
            OMP_NUM_THREADS=$THREAD ./benchmark-parallel-histogram datafiles/$ELEMENT-$BIN.arr $BIN $REPEATS >> benchmark.csv
            if (($? == 137));
            then
                echo "Killed" >> benchmark.csv
            fi
        done
    done
done

for ELEMENT in ${ELEMENTS[@]}; do
    for BIN in ${BINS[@]}; do
        for BLOCK in ${BLOCKS[@]}; do
            for THREAD in ${THREADS[@]}; do
                echo "Benchmarking histogram-blocked on datafiles/$ELEMENT-$BIN.arr with $THREAD thread(s) and $BLOCK block(s)"
                echo -n "blocked,$THREAD,$ELEMENT,$BIN,$BLOCK,," >> benchmark.csv
                OMP_NUM_THREADS=$THREAD ./benchmark-blocked-histogram datafiles/$ELEMENT-$BIN.arr $BIN $BLOCK $REPEATS >> benchmark.csv
                if (($? == 137));
                then
                    echo "Killed" >> benchmark.csv
                fi
            done
        done
    done
done

for ELEMENT in ${ELEMENTS[@]}; do
    for BIN in ${BINS[@]}; do
        for PASS in ${PASSES[@]}; do
            for THREAD in ${THREADS[@]}; do
                PERPASS=ex
                echo "Benchmarking histogram-multi-pass on datafiles/$ELEMENT-$BIN.arr with $THREAD thread(s) and $((BIN/PASS)) element(s) per pass"
                echo -n "multi-pass,$THREAD,$ELEMENT,$BIN,,$((BIN/PASS))," >> benchmark.csv
                OMP_NUM_THREADS=$THREAD ./benchmark-multi-pass-histogram datafiles/$ELEMENT-$BIN.arr $BIN $((BIN/PASS)) $REPEATS >> benchmark.csv
                if (($? == 137));
                then
                    echo "Killed" >> benchmark.csv
                fi
            done
        done
    done
done

for ELEMENT in ${ELEMENTS[@]}; do
    for BIN in ${BINS[@]}; do
        for BLOCK in ${BLOCKS[@]}; do
            for PASS in ${PASSES[@]}; do
                for THREAD in ${THREADS[@]}; do
                    echo "Benchmarking histogram-blocked-multi-pass on datafiles/$ELEMENT-$BIN.arr with $THREAD thread(s), $BLOCK block(s) and $((BIN/PASS)) element(s) per pass"
                    echo -n "blocked-multi-pass,$THREAD,$ELEMENT,$BIN,$BLOCK,$((BIN/PASS))," >> benchmark.csv
                    OMP_NUM_THREADS=$THREAD ./benchmark-blocked-multi-pass-histogram datafiles/$ELEMENT-$BIN.arr $BIN $BLOCK $((BIN/PASS)) $REPEATS >> benchmark.csv
                    if (($? == 137));
                    then
                        echo "Killed" >> benchmark.csv
                    fi
                done
            done
        done
    done
done

end_time=$(date +%s)
runtime=$(( end_time - start_time ))
echo "Total runtime: $runtime seconds"

#!/usr/bin/env bash

ELEMENTS=(10000 1000000 100000000 1000000000)
BINS=(128 2048 32768 524288 8388608 134217728)

mkdir -p datafiles
for ELEMENT in ${ELEMENTS[@]}; do
    for BIN in ${BINS[@]}; do
        echo "Generating file at datafiles/$ELEMENT-$BIN.arr" 
        ./random-array $ELEMENT $BIN datafiles/$ELEMENT-$BIN.arr
    done
done

#include "histogram.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void free_histogram(struct histogram* hist) {
  free(hist->bins);
  free(hist);
}

struct histogram* histogram_simple(struct array* arr, int bins) {
  struct histogram* hist = malloc(sizeof(struct histogram));
  hist->n = bins;
  hist->bins = calloc(hist->n, sizeof(int));

  // A crude histogram calculation, inspecting each element one by one
  for (int i=0; i<arr->n; i++) {
    int bin = (int)arr->elements[i];
    hist->bins[bin]++;
  }

  return hist;
}

struct histogram* histogram_parallel(struct array* arr, int bins) {
  struct histogram* hist = malloc(sizeof(struct histogram));
  hist->n = bins;
  hist->bins = calloc(hist->n, sizeof(int));

  // A crude histogram calculation, inspecting each element one by one
  #pragma omp parallel for 
  for (int i=0; i<arr->n; i++) {
    int bin = (int)arr->elements[i];
    #pragma omp atomic
    hist->bins[bin]++;
  }

  return hist;
}

struct histogram* histogram_blocked(struct array* arr, int bins, int blocks) {
  struct histogram* hist = malloc(sizeof(struct histogram));
  hist->n = bins;
  hist->bins = calloc(hist->n, sizeof(int));

  int block_len = arr->n / blocks;
  struct histogram** block_histograms = malloc(sizeof(struct histogram*) * blocks);

  // Setup block histogram
  for (int b=0; b<blocks; b++) {
    struct histogram* block_hist = malloc(sizeof(struct histogram));
    block_hist->n = bins;
    block_hist->bins = calloc(block_hist->n, sizeof(int));

    block_histograms[b] = block_hist;
  }

  // Divide the original array into blocks and inspect each element one by one
  #pragma omp parallel for collapse(2)
  for (int b=0; b<blocks; b++) {
    for (int i=0; i<block_len; i++) {
      int bin = (int)arr->elements[(b*block_len)+i];
      #pragma omp atomic
      block_histograms[b]->bins[bin]++;
    }
  }

  // Combine block histograms into result
  #pragma omp parallel for
  for (int i=0; i<hist->n; i++) {
    for (int b=0; b<blocks; b++) {
      hist->bins[i]+= block_histograms[b]->bins[i]; 
    }
  }

  // free blocks
  for (int b=0; b<blocks; b++) {
    free_histogram(block_histograms[b]);
  }
  free(block_histograms);
  return hist;
}

struct histogram* histogram_multipass(struct array* arr, int bins, int per_pass) {
  struct histogram* hist = malloc(sizeof(struct histogram));
  hist->n = bins;
  hist->bins = calloc(hist->n, sizeof(int));

  int passes = (int)ceil((double)bins / per_pass);

  // Divide the histogram bins into pass
  #pragma omp parallel for
  for (int p=0; p<passes; p++) {
    // Inspect each element in the array one by one
    for (int i=0; i<arr->n; i++) {
      // If the element is in range for this pass, update the histogram
      if (arr->elements[i] >= p*per_pass && arr->elements[i] < (p*per_pass)+per_pass) {
        int bin = (int)arr->elements[i];
        hist->bins[bin]++;
      }
    }
  }
  return hist;
}

struct histogram* histogram_blocked_multipass(struct array* arr, int bins, int blocks, int per_pass) {
  struct histogram* hist = malloc(sizeof(struct histogram));
  hist->n = bins;
  hist->bins = calloc(hist->n, sizeof(int));

  int block_len = arr->n / blocks;
  int passes = (int)ceil((double)bins / per_pass);
  struct histogram** block_histograms = malloc(sizeof(struct histogram*) * blocks);

  // Setup block histogram
  for (int b=0; b<blocks; b++) {
    struct histogram* block_hist = malloc(sizeof(struct histogram));
    block_hist->n = bins;
    block_hist->bins = calloc(block_hist->n, sizeof(int));

    block_histograms[b] = block_hist;
  }

  // Divide the original array into blocks
  #pragma omp parallel for collapse(2)
  for (int b=0; b<blocks; b++) {
    // Divide the histogram bins into pass
    for (int p=0; p<passes; p++) {
      // Inspect each element in the block one by one
      for (int i=0; i<block_len; i++) {
        int index = (b*block_len)+i;
        // If the element is in range for this pass, update the histogram
        if (arr->elements[index] >= p*per_pass && arr->elements[index] < (p*per_pass)+per_pass) {
          int bin = arr->elements[index];
          block_histograms[b]->bins[bin]++;
        }
      }
    }
  }

  // Combine block histograms into result
  #pragma omp parallel for
  for (int i=0; i<hist->n; i++) {
    for (int b=0; b<blocks; b++) {
      hist->bins[i]+= block_histograms[b]->bins[i]; 
    }
  }

  // free blocks
  for (int b=0; b<blocks; b++) {
    free_histogram(block_histograms[b]);
  } 
  free(block_histograms);

  return hist;
}

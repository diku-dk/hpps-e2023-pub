#include "array.h"
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char** argv) {
  if (argc != 2) {
    fprintf(stderr, "Usage: %s FILE\n", argv[0]);
    exit(1);
  }

  const char* file = argv[1];

  struct array* arr = read_array(file);

  if (arr == NULL) {
    fprintf(stderr, "Failed to read array from %s\n", file);
    exit(1);
  }

  int n = array_n(arr);

  for (int i = 0; i < n; i++) {
    printf("%f\n", array_idx(arr, i));
  }
  free_array(arr);
}

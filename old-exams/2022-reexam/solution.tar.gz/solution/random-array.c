#include <assert.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "timing.h"

int main(int argc, char** argv) {
  if (argc != 4) {
    fprintf(stderr, "Usage: %s ELEMS MAX FILE\n", argv[0]);
    exit(1);
  }

  int elems = atoi(argv[1]);

  int max = atoi(argv[2]);

  FILE* f = fopen(argv[3], "wr");
  assert(f != NULL);
  if (f == NULL) {
    fprintf(stderr, "Cannot open %s: %s\n", argv[1], strerror(errno));
    exit(1);
  }
  srand(microseconds()); // Initialise RNG.

  assert(fwrite(&elems, sizeof(int), 1, f) == 1);
  for (int i = 0; i < elems; i++) {
    double r = (rand() % max) + rand() / ((double)RAND_MAX);
    assert(fwrite(&r, sizeof(double), 1, f) == 1);
  }
  fclose(f);
}

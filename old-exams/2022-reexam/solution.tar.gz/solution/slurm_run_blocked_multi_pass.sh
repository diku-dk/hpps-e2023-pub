#!/usr/bin/env bash

export OMP_NUM_THREADS=${1}
echo "Benchmarking histogram-blocked-multi-pass on datafiles/${2}-${3}.arr with ${1} threads, ${4} blocks and ${5} elements per pass"
time ./benchmark-blocked-multi-pass-histogram datafiles/${2}-${3}.arr ${3} ${4} ${5} ${6}

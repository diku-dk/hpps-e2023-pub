#!/usr/bin/env bash

export OMP_NUM_THREADS=${1}
echo "Benchmarking histogram-parallel on datafiles/${2}-${3}.arr with ${1} threads"
time ./benchmark-parallel-histogram datafiles/${2}-${3}.arr ${3} ${4}

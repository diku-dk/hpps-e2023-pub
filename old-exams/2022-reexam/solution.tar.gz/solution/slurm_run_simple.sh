#!/usr/bin/env bash

echo "Benchmarking histogram-simple on datafiles/${1}-${2}.arr"
time ./benchmark-simple-histogram datafiles/${1}-${2}.arr ${2} ${3}

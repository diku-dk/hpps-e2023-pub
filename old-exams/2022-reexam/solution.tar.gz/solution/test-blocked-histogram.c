#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "histogram.h"
#include "timing.h"


int main(int argc, char** argv) {
  if (argc != 5) {
    fprintf(stderr, "Usage: %s ARRAY-FILE BLOCKS BINS RUNS\n", argv[0]);
    exit(1);
  }

  struct array* arr = read_array(argv[1]);
  if (arr == NULL) {
    fprintf(stderr, "Cannot read array from %s: %s\n", argv[1], strerror(errno));
    exit(1);
  }

  int bins = atoi(argv[2]);
  int blocks = atoi(argv[3]);
  int runs = atoi(argv[4]);

  struct histogram* ref_hist = malloc(sizeof(struct histogram));
  ref_hist->n = bins;
  ref_hist->bins = calloc(ref_hist->n, sizeof(int));

  for (int i=0; i<arr->n; i++) {
    int bin = (int)arr->elements[i];
    ref_hist->bins[bin]++;
  } 
  
  for (int r = 0; r < runs; r++) {
    struct histogram* test_hist = histogram_blocked(arr, bins, blocks);

    if (test_hist->n != ref_hist->n) {
      fprintf(stderr, "Incorrect bin count in histogram. Got %i but expected %i\n", test_hist->n, ref_hist->n);
      exit(1);
    }
  
    for (int i=0; i<ref_hist->n; i++) {
      if (test_hist->bins[i] != ref_hist->bins[i]) {
        fprintf(stderr, "Bin value mismatched for bin %i. Got %i but expected %i\n", i, test_hist->bins[i], ref_hist->bins[i]);
        exit(1);
      }
    }

    free_histogram(test_hist);
  }

  free_histogram(ref_hist);
  free_array(arr);
}

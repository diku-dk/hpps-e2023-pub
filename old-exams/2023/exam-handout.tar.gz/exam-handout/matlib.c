#include "matlib.h"
#include <assert.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>

// Scalar type

struct scalar {
  double value;
};

struct scalar* read_scalar(const char* file) {
  // Open file for reading, in binary mode.
  FILE *f = fopen(file, "rb");
  struct scalar* ret = NULL;

  // Fail quickly if we could not open the file.
  if (f == NULL) {
    return NULL;
  }

  // Make room for reading the four-byte magic number.
  char magic[4];

  // Read the magic number into 'magic'; jumping to the end if it goes
  // wrong.
  if (fread(magic, 4, 1, f) != 1) {
    goto end;
  }

  // Check if the magic number is as expected.  Here we exploit that
  // the magic number corresponds to an ASCII string.
  if (memcmp(magic,"SCLR",4) != 0) {
    goto end;
  }

  // Read the scalar.  It's 1 element of size sizeof(double).
  double v;
  if (fread(&v, sizeof(double), 1, f) != 1) {
    goto end;
  }

  // Allocate the scalar struct and write 'double' we read into it.
  ret = malloc(sizeof(struct scalar));
  ret->value = v;

  // Even if we get here due to a failure, we should still remember to
  // close the file.
 end:
  fclose(f);
  return ret;
}

int write_scalar(const char* file, struct scalar* s) {
  // Open file for writing, in binary mode.
  FILE* f = fopen(file, "wb");
  int ret = 0;

  // If we could not open it, return immediately.
  if (f == NULL) {
    return 1;
  }

  // Write the magic number to the file.  We exploit that the magic
  // number corresponds to a four-byte ASCII String.
  fprintf(f, "SCLR");
  // Then write the actual value.  Check that it goes well.
  if (fwrite(&s->value, sizeof(double), 1, f) != 1) {
    ret = 1;
  }

  // Remember to close the file.
  fclose(f);
  return ret;
}

void free_scalar(struct scalar* s) {
  // Free the struct allocated in read_scalar().
  free(s);
}

double scalar_value(struct scalar* s) {
  // Self-explanatory, I hope.
  return s->value;
}

// Vector type

struct vector {
  int n;
  double *elements;
};

struct vector* read_vector(const char* file) {
  assert(0);
}

int write_vector(const char* file, struct vector* v) {
  assert(0);
}

void free_vector(struct vector* v) {
  assert(0);
}

int vector_n(struct vector* v) {
  assert(0);
}

double vector_idx(struct vector* v, int i) {
  assert(0);
}

// Dense matrices

struct matrix_dense {
  int n;
  int m;
  double* elements;
};

struct matrix_dense* read_matrix_dense(const char* file) {
  assert(0);
}

int write_matrix_dense(const char* file, struct matrix_dense* X) {
  assert(0);
}

void free_matrix_dense(struct matrix_dense* X) {
  assert(0);
}

int matrix_dense_n(struct matrix_dense* X) {
  assert(0);
}

int matrix_dense_m(struct matrix_dense* X) {
  assert(0);
}

double matrix_dense_idx(struct matrix_dense* X, int i, int j) {
  assert(0);
}

// Sparse matrices in CSR format

struct matrix_csr {
  int n;
  int m;
  int nnz; // Number of nonzero entries.
  double *v; // Nonzero values, of length nnz.
  int *v_col; // Column of each value, of length nnz.
  int *row_start; // For each row number, offset in v where that row
                  // starts.
};

struct matrix_csr* read_matrix_csr(const char* file) {
  assert(0);
}

int write_matrix_csr(const char* file, struct matrix_csr* X) {
  assert(0);
}

void free_matrix_csr(struct matrix_csr* A) {
  assert(0);
}

int matrix_csr_n(struct matrix_csr* X) {
  assert(0);
}

int matrix_csr_m(struct matrix_csr* X) {
  assert(0);
}

double matrix_csr_idx(struct matrix_csr* A, int i, int j) {
  assert(0);
}

// Operations

struct scalar* mul_vv(struct vector* x, struct vector* y) {
  assert(0);
}

struct vector* mul_mv(struct matrix_dense* A, struct vector* x) {
  assert(0);
}

struct vector* mul_mTv(struct matrix_dense* A, struct vector* x) {
  assert(0);
}

struct vector* mul_spmv(struct matrix_csr* A, struct vector* x) {
  assert(0);
}

struct vector* mul_spmTv(struct matrix_csr* A, struct vector* x) {
  assert(0);
}
